# Requirement coverage and verification

Implementation date: 2026-10-15 (user's Asia/Tehran date). Editor: **6000.6.3f1 (45d8eee7de74)**. Dependencies and render pipeline are unchanged. The production scene/Inspector/art setup belongs to the user, as requested. Source coverage and passing disposable tests do not mean the final game scene is configured or visually accepted.

## Homework mapping

| ID | Source / delivered evidence | Verification and remaining production work |
| --- | --- | --- |
| HW-01 | WorldScrollController, ParallaxLayer; shared integrated step distance, overshoot-preserving wrapping/reset | Automated repeated-wrap coverage test. User must assign at least two visible sprite layers with different factors and verify seams at two aspect ratios. |
| HW-02 | RunnerControls.inputactions; RunnerInputReader serialized references; New Input setting already enabled | Input System Play Mode tests drive Space/Shift/Escape, release gates, and UI action ownership. User must wire InputSystemUIInputModule and menu actions, replace template project-wide actions, and validate navigation/pointer input. |
| HW-03 | PlayerHealth, constant MaximumLives=3, HudController Slider binding | Tests cover reset and 3->2->1->0. User must create/assign the visible health bar and observe all four values. |
| HW-04 | Gameplay/Jump Space, Gameplay/Dash Shift; PlayerController single jump/dash/cooldown; world speed burst and sprite tint | Action/physics tests cover press/hold, speed restoration and cooldown rejection. User must tune feel and confirm visible feedback in actual sprites. |
| HW-05 | PlayerHealth accepted-hit authority; session death transition; Interactable encounter guard; swept contact fallback | Tests cover one accepted hit, invulnerability, fatal hit, repeated restart, and entire-player crossing in a step. User must test both actual prefab colliders at maximum dash speed. |
| HW-06 | Concrete GroundObstacle, AerialObstacle, CoinCollectible; SpawnController cycles all three with randomized proposed waits | Automated contact/coin and spawn-cap coverage. User must create all three visible prefabs and validate height, reachability, and spawn fairness during actual play. |
| HW-07 | GroundObstacle/AerialObstacle -> Obstacle -> Interactable; CoinCollectible -> Interactable | Shared guarded polymorphic entry point exercised by tests. Player does not branch by concrete interaction type. |
| HW-08 | PlayerAnimationController validates required Base Layer states and all five parameter types, translates state, and resets Animator | Disposable Play Mode controller exercises Death transition and reset. User must create Run/Jump/Hit/Death production clips/controller and verify all transitions and distinct visible behavior. |
| HW-09 | PlayerHitFeedback captures original color, flashes, restores on expiry/death/reset/disable; dash uses separate tint | Pause/tint/restart tested. User must confirm contrast and appearance on actual sprites. |
| HW-10 | HudController score/high-score/health events; MenuController distinct panels/selection; six public GameSession button methods | Session pause/menu/restart guards and HUD bindings exercised in fixture. User must wire Buttons manually, validate actual layout/UI at timeScale zero and two aspect ratios. No code onClick registration exists. |
| HW-11 | PlayerPrefsHighScoreStore, key ChromeDino.HighScore.v1, dirty checkpoints in GameSession/ScoreTracker | Isolated-key store and high-score/dirty-write tests passed. User must close/reopen the standalone build with unchanged company/product identifiers. Editor fresh-store tests do not prove cross-launch build persistence. |

## Automated checks

The real Unity Editor is installed and licensed. The user already had the production project open, so validation uses an isolated **Temp/CodexValidation** copy of Assets, Packages, and ProjectSettings. Unity imports and compiles that copy normally. This avoids closing the user's Editor, opening a second instance on the same project, or changing their current scene.

No production scene/prefab YAML or Animator asset is generated. Play Mode fixtures create disposable objects and Animator data through Unity APIs, then destroy them. Their inactive Canvas permits model/HUD binding without font/art imports, so these tests do not validate rendered UI. Integration scoring uses an in-memory store; PlayerPrefs tests use a unique isolated key and delete only that key. Input tests use the installed Unity.InputSystem.TestFramework InputTestFixture, restoring Input System state. No runtime test cheats or extra package dependencies are introduced.

PowerShell invocation pattern (paths shown for this workspace; change them for another machine):

```powershell
& 'C:/Program Files/Unity/Hub/Editor/6000.6.3f1/Editor/Unity.exe' `
  -batchmode -nographics `
  -projectPath 'C:/Users/ToosArax/DinoRunner/Temp/CodexValidation' `
  -runTests -testPlatform EditMode `
  -testResults 'C:/Users/ToosArax/DinoRunner/Logs/Codex/EditMode-Final.xml' `
  -logFile 'C:/Users/ToosArax/DinoRunner/Logs/Codex/EditMode-Final.log'

# Run sequentially after the first Unity process has exited:
& 'C:/Program Files/Unity/Hub/Editor/6000.6.3f1/Editor/Unity.exe' `
  -batchmode -nographics `
  -projectPath 'C:/Users/ToosArax/DinoRunner/Temp/CodexValidation' `
  -runTests -testPlatform PlayMode `
  -testResults 'C:/Users/ToosArax/DinoRunner/Logs/Codex/PlayMode-Final.xml' `
  -logFile 'C:/Users/ToosArax/DinoRunner/Logs/Codex/PlayMode-Final.log'
```

Do not add `-quit` to these Test Runner commands; the runner exits on completion. Unity's Windows launcher may return before the test process finishes, so read the NUnit XML result and completed-run log, rather than interpreting the shell's immediate exit code as a passing test result. The ignored Logs/Codex directory retains local execution evidence. From a fresh checkout, run the suites in the configured project using the Test Runner; the temporary copy is not a required production dependency.

Final executed results:

| Check | Actual result / local evidence |
| --- | --- |
| Unity import and C# compilation | Completed in 6000.6.3f1; no C# compiler warnings or errors in final logs. |
| Edit Mode | **11 passed, 0 failed**, NUnit duration 0.0405404 s; `Logs/Codex/EditMode-Final.xml`, `Logs/Codex/EditMode-Final.log`. |
| Play Mode | **11 passed, 0 failed**, NUnit duration 0.7563561 s; `Logs/Codex/PlayMode-Final.xml`, `Logs/Codex/PlayMode-Final.log`. |
| Runtime source audit | No matches for legacy Input APIs, StandaloneInputModule, onClick, UnityEditor, TODO, NotImplementedException, or DeleteAll in Assets/_Project/Scripts. |
| Input JSON | Parsed successfully; Gameplay/System/UI maps contain the specified actions; IDs unique. Unity imported the asset and tests exercised its bindings. |
| Ignore baseline | Exact Appendix A content retained, plus the relevant `*.slnx` generated-solution rule. |
| Existing assets/configuration | Scene files, manifest, lockfile, Editor version, Player settings and build-scene settings match the pre-validation snapshot; no production YAML was edited. |
| Source parity / metadata | Final authored asset contents match the tested copy. New metadata comes from actual Unity import, copied only where missing; no guessed GUIDs. |
| Production build / visual acceptance | **Not run**; user scene/Inspector/art setup remains pending. |

The initial Edit Mode run passed the 10 model tests but failed four input tests because Edit Mode did not process their simulated player actions. Those cases were moved to supported Play Mode with the installed isolated InputTestFixture. A subsequent Play Mode run passed all 10 tests before the final parallax/freeze/cap additions. Final results above include those additions and supersede the initial attempts. Package resolution reused the existing exact versions without changing manifest or lockfile.

## Manual acceptance still required

- [ ] Complete all scene/Inspector/asset/layer/Animator/button mapping in [UnitySetup.md](UnitySetup.md).
- [ ] No missing references or Console errors when the configured Game scene starts; Main Menu shows Play/Quit/control hints.
- [ ] Play begins immediately with score zero and health three; live score/high-score stay visible throughout play and at GameOver.
- [ ] Actual Space jump, Shift dash, cooldown, airborne behavior, and ground detection feel correct at different frame rates.
- [ ] Ground hazards are jumpable; aerial hazards intersect jumps while safely clearing a grounded player; coins are reachable.
- [ ] All four actual Animator states and distinguishable clips work, including hit during jump and immediate fatal Death priority.
- [ ] Flash is brief, dash feedback visible, and both restore correctly after pause/death/restart/menu cycles.
- [ ] Escape and UI Pause/Resume work once per press; UI remains responsive at timeScale zero; holding Space/Shift across menus cannot activate a move.
- [ ] Death freezes player/hazards/spawning/score while its animation finishes; repeated Restart/Main Menu cycles restore everything.
- [ ] Two visible parallax layers wrap without seams at 16:9 and 4:3 and while dashing.
- [ ] Play several minutes to verify safe layouts and bounded live objects in the actual scene.
- [ ] A complete standalone build starts from Game.unity, quits correctly, and retains high score after closing/reopening.
- [ ] Git repository contains source, docs, Packages/lockfile, ProjectSettings, and Unity-generated metadata, with generated data/builds ignored.
- [ ] Complete student identity/repository URL, screenshots, short report/source acknowledgment, full runnable build, and required ZIP contents.

The source was implemented with Codex assistance; see README.md for sources and the student-review responsibility. No unaided-authorship claim, finished build, manual acceptance result, or submission is implied.
