using UnityEngine;

namespace ChromeDino
{
    public static class SpawnSpacing
    {
        public static float MinimumCenterDistance(RunnerSettings settings, float gravityMagnitude,
            float playerWidth, float previousWidth, float nextWidth)
        {
            float flightSeconds = 2f * settings.JumpVelocity / (gravityMagnitude * settings.GravityScale);
            float recoveryGap = settings.MaximumSpeed
                * (flightSeconds + settings.LandingRecoverySeconds + settings.ReactionSeconds);
            return (previousWidth + nextWidth) * 0.5f + playerWidth
                + Mathf.Max(settings.MinimumClearGapWorldUnits, recoveryGap);
        }
    }
}
