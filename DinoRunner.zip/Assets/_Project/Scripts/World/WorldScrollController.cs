using UnityEngine;

namespace ChromeDino
{
    [DisallowMultipleComponent]
    public sealed class WorldScrollController : MonoBehaviour
    {
        private RunnerSettings _settings;
        private PlayerController _player;
        private bool _running;

        public double TotalDistance { get; private set; }
        public float StepDistance { get; private set; }
        public float EffectiveSpeed => !_running ? 0f : _settings.BaseSpeed
            * (_player.IsDashing ? _settings.DashSpeedMultiplier : 1f);

        public void Initialize(RunnerSettings settings, PlayerController player)
        {
            _settings = settings;
            _player = player;
        }

        public void SetRunning(bool running) => _running = running;

        public void ResetRun()
        {
            _running = false;
            TotalDistance = 0d;
            StepDistance = 0f;
        }

        public void Tick(float deltaSeconds)
        {
            StepDistance = _running
                ? _settings.BaseSpeed * deltaSeconds * _player.ConsumeSpeedMultiplier(deltaSeconds) : 0f;
            TotalDistance += StepDistance;
        }
    }
}
