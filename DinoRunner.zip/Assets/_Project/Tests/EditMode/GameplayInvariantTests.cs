using System;
using NUnit.Framework;
using UnityEngine;

namespace ChromeDino.Tests
{
    public sealed class GameplayInvariantTests
    {
        private GameObject _root;
        private RunnerSettings _settings;
        private PlayerHealth _health;
        private ScoreTracker _score;
        private MemoryStore _store;
        private string _preferenceKey;

        [SetUp]
        public void SetUp()
        {
            _root = new GameObject("Invariant test");
            _settings = ScriptableObject.CreateInstance<RunnerSettings>();
            _health = _root.AddComponent<PlayerHealth>();
            _health.Initialize(_settings);
            _health.SetDamageEnabled(true);
            _store = new MemoryStore { Record = 5 };
            _score = _root.AddComponent<ScoreTracker>();
            _score.Initialize(1f, _store);
            _score.SetScoringEnabled(true);
            _preferenceKey = "ChromeDino.Tests." + Guid.NewGuid();
        }

        [TearDown]
        public void TearDown()
        {
            PlayerPrefs.DeleteKey(_preferenceKey);
            PlayerPrefs.Save();
            UnityEngine.Object.DestroyImmediate(_root);
            UnityEngine.Object.DestroyImmediate(_settings);
        }

        [Test]
        public void EligibleHitsReachZeroOnceAndCannotBecomeNegative()
        {
            int deaths = 0;
            int nonfatalHits = 0;
            _health.Died += () => deaths++;
            _health.Damaged += () => nonfatalHits++;
            Assert.That(_health.CurrentLives, Is.EqualTo(3));
            for (int lives = 2; lives >= 0; lives--)
            {
                Assert.That(_health.TryTakeDamage(), Is.True);
                Assert.That(_health.CurrentLives, Is.EqualTo(lives));
                Assert.That(_health.TryTakeDamage(), Is.False);
                _health.Tick(_settings.InvulnerabilitySeconds + 0.01f);
            }

            Assert.That(deaths, Is.EqualTo(1));
            Assert.That(nonfatalHits, Is.EqualTo(2));
            Assert.That(_health.IsRecovering, Is.False);
        }

        [Test]
        public void PausedHealthPreservesRemainingRecoveryAndInvulnerability()
        {
            _health.TryTakeDamage();
            _health.SetDamageEnabled(false);
            _health.Tick(100f);
            Assert.That(_health.IsRecovering, Is.True);
            Assert.That(_health.TryTakeDamage(), Is.False);
            _health.SetDamageEnabled(true);
            _health.Tick(_settings.HitRecoverySeconds);
            Assert.That(_health.IsRecovering, Is.False);
            Assert.That(_health.IsInvulnerable, Is.True);
            _health.Tick(_settings.InvulnerabilitySeconds);
            Assert.That(_health.TryTakeDamage(), Is.True);
        }

        [Test]
        public void ReentrantDamageCannotRemoveAnotherLife()
        {
            _health.Damaged += () => Assert.That(_health.TryTakeDamage(), Is.False);
            _health.TryTakeDamage();
            Assert.That(_health.CurrentLives, Is.EqualTo(2));
        }

        [Test]
        public void ResetRestoresThreeLivesAndRetainsRecord()
        {
            _health.TryTakeDamage();
            _score.AddItemPoints(10);
            _health.ResetRun();
            _score.ResetRun();
            Assert.That(_health.CurrentLives, Is.EqualTo(3));
            Assert.That(_health.IsInvulnerable, Is.False);
            Assert.That(_score.CurrentScore, Is.Zero);
            Assert.That(_score.HighScore, Is.EqualTo(10));
            Assert.That(_store.Record, Is.EqualTo(10));
        }

        [Test]
        public void FractionalDistanceAccumulatesAndCoinAddsExactlyItsPoints()
        {
            _score.SetDistance(0.4d);
            _score.SetDistance(0.8d);
            _score.SetDistance(1.2d);
            _score.AddItemPoints(_settings.CoinPoints);
            Assert.That(_score.CurrentScore, Is.EqualTo(11));
            Assert.That(_score.HighScore, Is.EqualTo(11));
        }

        [Test]
        public void StoppedScoreRejectsDistanceAndItems()
        {
            _score.SetDistance(2.5d);
            _score.SetScoringEnabled(false);
            _score.SetDistance(100d);
            _score.AddItemPoints(10);
            Assert.That(_score.CurrentScore, Is.EqualTo(2));
        }

        [Test]
        public void ScoreSaturatesAndRejectsInvalidRequests()
        {
            _score.SetDistance(double.NaN);
            _score.SetDistance(-1d);
            _score.AddItemPoints(-10);
            Assert.That(_score.CurrentScore, Is.Zero);
            _score.AddItemPoints(int.MaxValue);
            _score.AddItemPoints(int.MaxValue);
            _score.SetDistance(double.MaxValue);
            Assert.That(_score.CurrentScore, Is.EqualTo(int.MaxValue));
        }

        [Test]
        public void RecordIsDirtyUntilCheckpointAndLowerRunCannotOverwriteIt()
        {
            _score.AddItemPoints(20);
            Assert.That(_store.Saves, Is.Zero);
            _score.FlushHighScore();
            _score.FlushHighScore();
            Assert.That(_store.Saves, Is.EqualTo(1));
            _score.ResetRun();
            _score.SetScoringEnabled(true);
            _score.AddItemPoints(2);
            _score.FlushHighScore();
            Assert.That(_store.Record, Is.EqualTo(20));
            Assert.That(_store.Saves, Is.EqualTo(1));
        }

        [Test]
        public void PlayerPrefsStoreHandlesMissingNegativeAndFreshInstance()
        {
            PlayerPrefsHighScoreStore store = new PlayerPrefsHighScoreStore(_preferenceKey);
            Assert.That(store.Load(), Is.Zero);
            PlayerPrefs.SetInt(_preferenceKey, -7);
            Assert.That(store.Load(), Is.Zero);
            store.Save(42);
            PlayerPrefsHighScoreStore reopened = new PlayerPrefsHighScoreStore(_preferenceKey);
            Assert.That(reopened.Load(), Is.EqualTo(42));
            reopened.Save(2);
            Assert.That(store.Load(), Is.EqualTo(42));
        }

        [Test]
        public void SpacingIncludesMaximumSpeedFlightReactionAndBothWidths()
        {
            float spacing = SpawnSpacing.MinimumCenterDistance(_settings, 9.81f, 1f, 1f, 2f);
            float flight = 2f * _settings.JumpVelocity / (9.81f * _settings.GravityScale);
            float requiredGap = _settings.MaximumSpeed
                * (flight + _settings.LandingRecoverySeconds + _settings.ReactionSeconds);
            Assert.That(spacing - 1.5f - 1f, Is.GreaterThanOrEqualTo(requiredGap - 0.0001f));
        }

        private sealed class MemoryStore : IHighScoreStore
        {
            public int Record;
            public int Saves;
            public int Load() => Record;
            public void Save(int highScore)
            {
                Record = highScore;
                Saves++;
            }
        }
    }
}
